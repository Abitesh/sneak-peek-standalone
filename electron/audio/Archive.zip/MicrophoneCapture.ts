import { EventEmitter } from 'events';
import { loadNativeModule } from './nativeModuleLoader';
import { normalizeSpeechEdge } from './speechEdge';

// RustMicCapture is the native Rust class (napi-rs) that captures microphone input.
// Uses LAZY init — the native monitor is NOT created in the constructor. Constructing
// the wrapper must NOT touch macOS CoreAudio HAL: doing so lights the orange menu-bar
// microphone-in-use indicator, which would be on for the lifetime of the process even
// though no meeting is active (the user-facing invariant we're protecting here).
// The native monitor is constructed in start() (the only point at which capture is
// actually requested) and in the post-stop() pre-warm path (gated on preWarmEnabled).
const NativeModule: any = loadNativeModule();
const { MicrophoneCapture: RustMicCapture } = NativeModule || {};

export class MicrophoneCapture extends EventEmitter {
    private monitor: any = null;
    private isRecording: boolean = false;
    private deviceId: string | null = null;
    // Promise that resolves when the deferred native teardown setImmediate body
    // finishes (i.e. monitor.stop() has released the cpal stream / HAL handle).
    // Tracked so:
    //   - repeated stop() calls return the same in-flight promise (idempotent),
    //   - callers can `await capture.stop()` to know teardown is genuinely
    //     complete before constructing a new native instance / starting again,
    //   - destroy() awaits this before removing listeners and nulling fields.
    private _teardownPromise: Promise<void> | null = null;
    // Resolves when the setImmediate orphan-stop scheduled by a FAILED start()
    // has actually released the native handle. start()'s failure path nulls
    // this.monitor synchronously but defers `dying.stop()` by a tick, so
    // "monitor === null" alone does NOT mean the HAL is free — retargetDevice()
    // awaits this before letting a caller open a different device.
    private _orphanTeardown: Promise<void> | null = null;
    // When false, the post-teardown pre-warm step (which constructs a fresh
    // RustMicCapture so the next meeting's start() doesn't pay the cpal init
    // cost on the Electron main thread) is skipped. Disabled by:
    //   - destroy() — permanent disposal, the wrapper will never be used again
    //   - disablePreWarm() — called from main.ts during app quit, aborted
    //     meeting init, and device-swap paths where the next start (if any)
    //     will construct a brand-new MicrophoneCapture instance anyway.
    //   - the wrapper has never had a successful start() — there's no evidence
    //     the user will ever need the warm instance, so don't re-open the cpal
    //     stream during the gap between endMeeting() and the next startMeeting().
    // Default false: the first meeting pays the cold-start cost once, and every
    // subsequent meeting benefits from pre-warm (preWarmEnabled flips to true
    // inside start() after a successful monitor.start).
    private preWarmEnabled: boolean = false;

    constructor(deviceId?: string | null) {
        super();
        this.deviceId = deviceId || null;
        if (!RustMicCapture) {
            console.error('[MicrophoneCapture] Rust class implementation not found.');
        } else {
            // LAZY INIT: do NOT construct the native monitor here. Doing so opens
            // a cpal input stream on macOS and lights the orange menu-bar mic-in-use
            // indicator — even though no meeting has started. Construction is
            // deferred to start() (when the user actually needs capture) and to
            // the gated post-stop() pre-warm path.
            console.log(`[MicrophoneCapture] Initialized wrapper (lazy). Device ID: ${this.deviceId || 'default'}`);
        }
    }

    public getSampleRate(): number {
        if (this.monitor) {
            // NAPI-RS V3 auto-converts Rust snake_case to camelCase
            if (typeof this.monitor.getSampleRate === 'function') {
                return this.monitor.getSampleRate();
            } else if (typeof this.monitor.get_sample_rate === 'function') {
                // Fallback for V2 or explicit js_name
                return this.monitor.get_sample_rate();
            }
        }
        return 48000; // Safe default for most modern mics before native initialization
    }

    /**
     * The NATIVE hardware sample rate (e.g. 24000 when AirPods are in Bluetooth
     * HFP "call mode", 48000 for the built-in mic) — distinct from getSampleRate(),
     * which returns the canonical EMITTED rate (16000) after the DSP resampler.
     * Used for HFP/Bluetooth-degradation detection. Returns 0 if unavailable.
     */
    public getNativeSampleRate(): number {
        if (this.monitor) {
            if (typeof this.monitor.getNativeSampleRate === 'function') {
                return this.monitor.getNativeSampleRate();
            } else if (typeof this.monitor.get_native_sample_rate === 'function') {
                return this.monitor.get_native_sample_rate();
            }
        }
        return 0;
    }

    /**
     * Re-point this wrapper at a different input device.
     *
     * Exists for the "saved device is gone" retry: because init is LAZY, a bad
     * device id cannot be detected until start() constructs the native monitor
     * and throws. Re-targeting THIS instance and starting again is cheaper and
     * safer than destroy/recreate — the caller keeps its wireMicCapture()
     * wiring — and awaiting any pending orphan teardown (below) keeps a closing
     * handle from racing the fresh device open.
     *
     * Deliberately refuses to run on a live wrapper: swapping deviceId while a
     * cpal stream is open would silently desync this.deviceId from the device
     * actually being captured.
     */
    public async retargetDevice(deviceId?: string | null): Promise<void> {
        if (this.monitor || this.isRecording) {
            throw new Error(
                '[MicrophoneCapture] retargetDevice() requires an inactive wrapper with no native monitor',
            );
        }
        // Two distinct start() failure paths, only one of which leaves the HAL
        // free immediately:
        //   - `new RustMicCapture()` threw  -> no handle was ever opened.
        //   - `monitor.start()` threw       -> a handle WAS opened; the catch
        //     nulls this.monitor but defers its stop() by a tick.
        // Awaiting here is what actually delivers the "no teardown racing a
        // fresh device open" property this method claims — without it, the
        // caller's next start() opens a second native handle while the first is
        // still closing, and if the failed id resolved to the current default
        // they contend for the same device (Windows WASAPI exclusive mode).
        if (this._orphanTeardown) {
            await this._orphanTeardown;
            this._orphanTeardown = null;
        }
        this.deviceId = deviceId || null;
        // A wrapper that has never captured successfully must not re-open the
        // mic during stop()'s post-teardown pre-warm (same rule start()'s
        // failure path enforces).
        this.preWarmEnabled = false;
        console.log(`[MicrophoneCapture] Re-targeted to device: ${this.deviceId || 'default'}`);
    }

    /**
     * Start capturing microphone audio
     */
    public start(): void {
        if (this.isRecording) return;

        if (!RustMicCapture) {
            console.error('[MicrophoneCapture] Cannot start: Rust module missing');
            // F-107: see SystemAudioCapture.start() — a silent return here hid
            // a missing/wrong-arch native module entirely. Throwing matches
            // this wrapper's existing construction-failure contract and lets
            // every call site surface a terminal channel banner.
            throw new Error('Native audio engine unavailable — the audio capture module failed to load. Reinstall the app (dev: npm run build:native).');
        }

        // PRIMARY construction site (lazy init). The wrapper does NOT construct
        // a native monitor in its constructor — doing so would open a cpal
        // input stream on macOS and light the orange mic-in-use indicator at
        // app launch (see constructor comments). Construction is deferred to
        // here, where the user has actually requested capture. The branch is
        // also defensive: if the native monitor was externally freed (edge
        // case) we still recover cleanly.
        if (!this.monitor) {
            console.log('[MicrophoneCapture] Constructing native monitor (lazy start-time init)...');
            try {
                this.monitor = new RustMicCapture(this.deviceId);
            } catch (e) {
                this.emit('error', e);
                // Preserve the pre-lazy-init contract: native construction
                // failures are catchable by the caller (startMeeting,
                // reconfigureAudio, audio-test fallback). Emitting alone would
                // silently skip those existing try/catch UI/error paths.
                throw e;
            }
        }

        try {
            console.log('[MicrophoneCapture] Starting native capture...');

            this.isRecording = true; // Set BEFORE start() to prevent re-entrant calls

            this.monitor.start((err: Error | null, chunk: Buffer) => {
                // napi v3 ThreadsafeFunction passes (err, arg) format
                if (err) {
                    console.error('[MicrophoneCapture] Callback error:', err);
                    this.isRecording = false; // Allow recovery via restart
                    this.preWarmEnabled = false;
                    this.emit('error', err);
                    return;
                }
                if (chunk && chunk.length > 0) {
                    // POST-STOP GUARD: see SystemAudioCapture for rationale. The
                    // deferred native stop() means late chunks may arrive on the JS
                    // side; drop them so STT.finalize() sees a clean audio-end.
                    if (!this.isRecording) return;
                    // Debug: log occasionally
                    if (Math.random() < 0.05) {
                        console.log(`[MicrophoneCapture] Emitting chunk: ${chunk.length} bytes to JS`);
                    }
                    // PERF: napi-rs Buffer is already owned. Removed redundant Buffer.from copy
                    // (matches SystemAudioCapture). Saves ~95KB/sec of allocation churn.
                    this.emit('data', chunk);
                }
            }, (err: Error | null, _ended: boolean) => {
                // Speech-ended callback from Rust SilenceSuppressor.
                // _ended is always `true` when fired (Rust only invokes on speech→silence transition).
                if (err) {
                    console.error('[MicrophoneCapture] Speech ended callback error:', err);
                    return;
                }
                this.emit('speech_ended');
            }, (err: Error | null, edge: any) => {
                // Joint dual-channel transition (Auto Answer V3, Amendment 1).
                // Optional third callback; absent consumers cost nothing.
                if (err) {
                    console.error('[MicrophoneCapture] Speech edge callback error:', err);
                    return;
                }
                const normalized = normalizeSpeechEdge(edge);
                if (normalized) this.emit('speech_edge', normalized);
            });

            // Enable pre-warm for the NEXT stop() cycle only after the JS-side
            // native start call returned successfully. If monitor.start() throws,
            // the catch below keeps preWarmEnabled=false so a failed start cannot
            // reopen the mic in stop()'s post-teardown pre-warm.
            this.preWarmEnabled = true;
            this.emit('start');
        } catch (error) {
            console.error('[MicrophoneCapture] Failed to start:', error);
            this.isRecording = false;
            this.preWarmEnabled = false;
            // ORPHAN-HANDLE FIX (F-106) — mirror of SystemAudioCapture's:
            // construction already opened the cpal input stream (macOS orange
            // mic indicator, Windows device handle), and with isRecording
            // false every later stop()/destroy() early-returns — the open
            // device would be held until the GC finalizer runs, blocking
            // immediate retries (Settings > Audio test) and keeping the
            // indicator lit. Stop the dying instance on the next tick so the
            // device releases deterministically; the next start() takes the
            // lazy-init branch and constructs fresh.
            const dying = this.monitor;
            this.monitor = null;
            if (dying) {
                this._orphanTeardown = new Promise<void>((resolve) => {
                    setImmediate(() => {
                        try {
                            dying.stop();
                        } catch (e) {
                            console.error('[MicrophoneCapture] Error stopping orphaned monitor after failed start:', e);
                        } finally {
                            resolve();
                        }
                    });
                });
            }
            this.emit('error', error);
            throw error;
        }
    }

    /**
     * Stop capturing.
     *
     * PERF: The native `monitor.stop()` blocks waiting for the DSP thread join
     * AND CPAL stream drop (which itself waits for the platform audio thread —
     * CoreAudio / WASAPI / ALSA — to release the device). On macOS that's
     * 30–80ms; on Windows 100–300ms; on flaky USB devices, longer. We flip
     * `isRecording = false` synchronously so external observers (and our own
     * data-callback guard) see the stopped state immediately, then defer the
     * native teardown so the Electron IPC handler returns without waiting.
     */
    public stop(): Promise<void> {
        // Idempotent: a concurrent stop() (e.g. endMeeting racing an audio
        // recovery teardown) joins the in-flight teardown instead of
        // starting a second one. If we are not recording AND no teardown is
        // in flight, this is a no-op resolved promise.
        if (!this.isRecording) {
            return this._teardownPromise ?? Promise.resolve();
        }

        console.log('[MicrophoneCapture] Stopping capture (deferred native teardown)...');
        this.isRecording = false;
        const monitor = this.monitor;
        // Null the field so any caller that wins the race against the setImmediate
        // below sees a clean slate. The setImmediate callback will eagerly
        // reconstruct a fresh Rust monitor before the next meeting starts.
        this.monitor = null;

        // Native teardown only — the setImmediate body releases the HAL
        // handle and resolves the promise. Pre-warm has been pulled OUT of
        // this body (it used to run inside the same setImmediate). Now it
        // runs in a separate .then() chained off the teardown promise so
        // that:
        //   1. `await capture.stop()` resolves the instant the OS-side
        //      handle is gone — callers waiting on teardown don't pay the
        //      pre-warm cost.
        //   2. Pre-warm is gated on `this.preWarmEnabled`, which destroy()
        //      and disablePreWarm() flip to false. Without this gate, the
        //      old in-body pre-warm would happily construct a fresh native
        //      handle during app quit, device swap, or aborted meeting init
        //      — wasted work in every case, and on `before-quit` an actual
        //      bug (we'd grab the OS mic for a process about to die).
        const teardownPromise = new Promise<void>((resolve) => {
            setImmediate(() => {
                try {
                    monitor?.stop();
                } catch (e) {
                    console.error('[MicrophoneCapture] Error stopping (deferred):', e);
                }
                resolve();
            });
        });
        this._teardownPromise = teardownPromise;

        // After teardown settles: clear the in-flight slot, then conditionally
        // pre-warm. Order matters — the slot clear must happen before
        // pre-warm so that a fast `await stop(); start()` sequence sees a
        // clean state on entry to start(), and the pre-warm's `!this.monitor`
        // check below correctly skips if start() already constructed one.
        void teardownPromise.then(() => {
            if (this._teardownPromise === teardownPromise) {
                this._teardownPromise = null;
            }
            if (!this.preWarmEnabled) return;
            if (!RustMicCapture) return;
            if (this.monitor) return;  // start() raced ahead and already grabbed a fresh handle
            try {
                console.log('[MicrophoneCapture] Pre-warming native monitor for next meeting...');
                this.monitor = new RustMicCapture(this.deviceId);
            } catch (e) {
                // Emit a structured event so observers (main.ts handles
                // 'error', AudioRecovery, telemetry) see the failure
                // instead of it being buried in console output. The
                // defensive branch in start() (line ~64) will still retry
                // construction synchronously — at that point the failure
                // surfaces as a normal start error to the user. The event
                // here is purely for diagnostics on why the next start
                // suffered the main-thread HAL stall.
                console.error('[MicrophoneCapture] Pre-warm failed (next start() will retry):', e);
                // Snake_case to match sibling events on this class
                // (speech_ended, sample_rate_changed).
                this.emit('pre_warm_failed', e);
            }
        });

        this.emit('stop');
        return teardownPromise;
    }

    /**
     * Permanently disable the post-teardown pre-warm step.
     *
     * Callers from main.ts use this in three situations:
     *   - app `before-quit`: process is exiting; grabbing the OS mic now
     *     leaks a native handle past V8 teardown.
     *   - device swap (reconfigureAudio): the next start will construct a
     *     brand-new MicrophoneCapture for the new device — pre-warming the
     *     OLD device would build a handle that nothing ever uses.
     *   - aborted meeting init: the user cancelled before any audio reached
     *     the STT; there is no "next start" imminent enough to justify the
     *     cpal cold-start work.
     *
     * destroy() flips this flag automatically before awaiting stop(), so
     * callers using destroy() do not need a separate disablePreWarm() call.
     */
    public disablePreWarm(): void {
        this.preWarmEnabled = false;
    }

    public async destroy(): Promise<void> {
        // Disable pre-warm BEFORE awaiting stop(). Without this, the
        // teardown promise's .then() would happily reconstruct a fresh
        // RustMicCapture immediately after monitor.stop() — only to be
        // nulled again at the bottom of this method. Wasted FFI work on
        // every destroy, and a small window where this.monitor briefly
        // points at a handle the caller considers dead.
        this.preWarmEnabled = false;
        await this.stop();
        this.removeAllListeners();
        this.monitor = null;
    }
}
